Dear Grader,

This latest submission contains multiple readability and code-formatting enhancements. 
The initial submission looks a bit too fuzzy with a lot out debug logs. Hope this one can make it easier for you to grade.
However, please disregard this if professor decides to impose a significant late penalty on this assignment.

Cheers,
Jerry